# Prompt untuk generate ulang sprite (kandang pixel art & animasi jalan Triceratops)

Latar: minta "solid flat white background, no checkerboard", lalu hapus latar dengan remove.bg, simpan PNG.

## 1. Kandang (3 level, pixel art top-down)
16-bit pixel art, STRICTLY top-down overhead view (flat, not isometric, not 3D render), same style as a cute
pixel-art Triceratops: clean 1px dark outlines, limited 24-color palette, no anti-aliasing, no blur, no gradients,
no text. Three square dinosaur enclosures side by side, equal size, each seen from directly above, empty inside
(no dinosaur), with an open grassy interior and a gate in the middle of the bottom fence.
Level 1: simple wooden fence, plain grass with a few flowers.
Level 2: stronger stone-and-wood fence, rocks and a small pond.
Level 3: steel reinforced fence with a watchtower in one corner, trees, and a mud pit.
Solid flat white background, no ground shadow, no checkerboard.

## 2. Animasi jalan Triceratops (gerakan jelas)
Pixel art sprite sheet, 4 rows x 6 columns, each cell identical size, a cute blue Triceratops with cream horns,
cream frill spikes and darker blue spots (same design as the reference). Each row is a 6-frame WALK CYCLE with
CLEARLY DIFFERENT leg positions in every frame (contact, down, passing, contact with opposite legs, down, passing),
body bobbing up and down 2px, tail swaying, head slightly nodding.
Row 1: facing the camera (walking down). Row 2: full side profile facing LEFT. Row 3: full side profile facing
RIGHT. Row 4: seen from behind (walking up).
Clean 1px dark outline, limited palette, no anti-aliasing, no text, solid flat white background, evenly spaced.

## Cara memasang
1. Simpan hasil (latar sudah dihapus) menimpa tools/source_sheets/dino_walk.png dan tools/source_sheets/enclosures.png.
2. Kalau jumlah frame jalan bukan 4, ubah WALK_COLS di tools/slice_sheets.py (mis. 6).
3. Jalankan: python tools/slice_sheets.py   (butuh pip install pillow numpy)
4. Kalau interior kandang baru terlihat salah (dino keluar pagar), sesuaikan ENCLOSURE_INTERIOR di scripts/game_data.gd.
