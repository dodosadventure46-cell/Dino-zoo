#!/usr/bin/env python3
"""Memotong sprite sheet mentah (tools/source_sheets/*.png) jadi sprite satuan di assets/.

Pakai:  python tools/slice_sheets.py        (butuh: pip install pillow numpy)

Ganti sheet di tools/source_sheets/ dengan hasil generate ulang (nama file sama),
ubah jumlah kolom/baris di bagian KONFIGURASI kalau berbeda, lalu jalankan skrip ini.
Latar sheet harus transparan (hasil remove.bg / PNG RGBA).
"""
import os
import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "tools", "source_sheets")
OUT = os.path.join(ROOT, "assets")
ALPHA_T = 24

# ---------------- KONFIGURASI ----------------
WALK_ROWS = ["down", "left", "right", "up"]  # urutan baris sheet jalan Triceratops
WALK_COLS = 4          # jumlah frame jalan per arah (ganti 6 kalau animasi baru 6 frame)
EAT_SLEEP_COLS = 4     # frame makan (baris 1) dan tidur (baris 2)
DINO_TARGET_W = 120    # lebar maksimum sprite dino di game (px)
VISITOR_TARGET_H = 62  # tinggi pengunjung di game (px)
VISITOR_DIRS = ["down", "left", "right", "up"]
VISITOR_GROUPS = 4     # jumlah karakter pengunjung
VISITOR_FRAMES = 4
ENCLOSURE_TARGET_W = 300
TILE_NAMES = [
    "grass_a", "grass_b", "grass_yellow", "dirt",
    "stone", "dirt_corner", "dirt_t", "dirt_h",
    "dirt_v", "water", "sand", "grass_flowers",
    "rocks_a", "rocks_b", "rocks_c", "rocks_d",
]
FACILITY_NAMES = ["gerbang", "warung", "suvenir", "toilet", "bangku", "tong", "pohon", "lampu"]
FACILITY_WIDTHS = [190, 130, 130, 130, 80, 44, 110, 44]
ICON_NAMES = ["coin", "upgrade", "hammer", "egg", "visitor", "stars", "meat", "gear"]
# ---------------------------------------------


def load(name):
    return Image.open(os.path.join(SRC, name)).convert("RGBA")


def mask_of(img):
    return np.array(img)[:, :, 3] > ALPHA_T


def runs(profile, min_gap):
    res, start, last, gap = [], None, 0, 0
    for i, v in enumerate(profile):
        if v:
            if start is None:
                start = i
            last = i
            gap = 0
        elif start is not None:
            gap += 1
            if gap >= min_gap:
                res.append((start, last))
                start = None
    if start is not None:
        res.append((start, last))
    return res


def split(profile, n):
    """Bagi profil 1D jadi tepat n bagian (cari celah kosong; kalau gagal bagi rata)."""
    for g in range(80, 0, -1):
        r = runs(profile, g)
        if len(r) == n:
            return r
    idx = np.where(profile)[0]
    a, b = int(idx[0]), int(idx[-1]) + 1
    step = (b - a) / n
    return [(int(a + i * step), int(a + (i + 1) * step) - 1) for i in range(n)]


def tight(m, x0, y0, x1, y1):
    sub = m[y0:y1 + 1, x0:x1 + 1]
    ys = np.where(sub.any(axis=1))[0]
    xs = np.where(sub.any(axis=0))[0]
    return (x0 + int(xs[0]), y0 + int(ys[0]), x0 + int(xs[-1]) + 1, y0 + int(ys[-1]) + 1)


def grid_boxes(img, rows, cols):
    m = mask_of(img)
    out = []
    for (y0, y1) in split(m.any(axis=1), rows):
        row = []
        for (x0, x1) in split(m[y0:y1 + 1].any(axis=0), cols):
            row.append(tight(m, x0, y0, x1, y1))
        out.append(row)
    return out


def grouped_boxes(img, rows, groups, per_group):
    """Untuk sheet dengan kelompok (mis. 4 karakter x 4 frame dalam satu baris)."""
    m = mask_of(img)
    row_runs = split(m.any(axis=1), rows)
    grp_runs = split(m.any(axis=0), groups)
    out = []
    for (y0, y1) in row_runs:
        row = []
        for (gx0, gx1) in grp_runs:
            sub = m[y0:y1 + 1, gx0:gx1 + 1]
            for (x0, x1) in split(sub.any(axis=0), per_group):
                row.append(tight(m, gx0 + x0, y0, gx0 + x1, y1))
        out.append(row)
    return out


def resize(img, s):
    w, h = max(1, round(img.width * s)), max(1, round(img.height * s))
    return img.convert("RGBa").resize((w, h), Image.LANCZOS).convert("RGBA")


def uniform(crops, scale):
    rs = [resize(c, scale) for c in crops]
    W, H = max(r.width for r in rs), max(r.height for r in rs)
    res = []
    for r in rs:
        c = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        c.paste(r, ((W - r.width) // 2, H - r.height))
        res.append(c)
    return res


def save(img, *parts):
    p = os.path.join(OUT, *parts)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p)


def do_dino():
    img = load("dino_walk.png")
    boxes = grid_boxes(img, len(WALK_ROWS), WALK_COLS)
    crops = [img.crop(b) for row in boxes for b in row]
    scale = DINO_TARGET_W / max(c.width for c in crops)
    fr = uniform(crops, scale)
    k = 0
    for d in WALK_ROWS:
        for i in range(WALK_COLS):
            save(fr[k], "dino", f"tri_walk_{d}_{i}.png")
            k += 1
    img = load("dino_eat_sleep.png")
    boxes = grid_boxes(img, 2, EAT_SLEEP_COLS)
    crops = [img.crop(b) for row in boxes for b in row]
    scale = DINO_TARGET_W / max(c.width for c in crops)
    fr = uniform(crops, scale)
    k = 0
    for name in ["eat", "sleep"]:
        for i in range(EAT_SLEEP_COLS):
            save(fr[k], "dino", f"tri_{name}_{i}.png")
            k += 1


def do_visitors():
    img = load("visitors.png")
    boxes = grouped_boxes(img, len(VISITOR_DIRS), VISITOR_GROUPS, VISITOR_FRAMES)
    crops = [img.crop(b) for row in boxes for b in row]
    scale = VISITOR_TARGET_H / max(c.height for c in crops)
    fr = uniform(crops, scale)
    per_row = VISITOR_GROUPS * VISITOR_FRAMES
    for r, d in enumerate(VISITOR_DIRS):
        for g in range(VISITOR_GROUPS):
            for f in range(VISITOR_FRAMES):
                save(fr[r * per_row + g * VISITOR_FRAMES + f], "visitors", f"v{g}_{d}_{f}.png")


def do_enclosures():
    img = load("enclosures.png")
    boxes = grid_boxes(img, 1, 3)[0]
    crops = [img.crop(b) for b in boxes]
    scale = ENCLOSURE_TARGET_W / max(c.width for c in crops)
    for i, c in enumerate(crops):
        save(resize(c, scale), "enclosure", f"kandang_{i + 1}.png")


def do_tiles():
    img = load("tiles.png")
    boxes = grid_boxes(img, 4, 4)
    k = 0
    for row in boxes:
        for (x0, y0, x1, y1) in row:
            ins = int(0.06 * (x1 - x0))
            t = img.crop((x0 + ins, y0 + ins, x1 - ins, y1 - ins))
            save(t.convert("RGBa").resize((64, 64), Image.LANCZOS).convert("RGBA"), "tiles", f"{TILE_NAMES[k]}.png")
            k += 1


def do_facilities():
    img = load("facilities.png")
    boxes = grid_boxes(img, 2, 4)
    k = 0
    for row in boxes:
        for b in row:
            c = img.crop(b)
            save(resize(c, FACILITY_WIDTHS[k] / c.width), "facilities", f"{FACILITY_NAMES[k]}.png")
            k += 1


def do_icons():
    img = load("icons.png")
    boxes = grid_boxes(img, 2, 4)
    k = 0
    for row in boxes:
        for b in row:
            c = img.crop(b)
            save(resize(c, 44 / max(c.width, c.height)), "icons", f"{ICON_NAMES[k]}.png")
            k += 1


def do_launcher_icon():
    p = os.path.join(OUT, "dino", "tri_walk_down_0.png")
    d = Image.open(p).convert("RGBA")
    s = 150 / max(d.width, d.height)
    d = d.resize((round(d.width * s), round(d.height * s)), Image.NEAREST)
    bg = Image.new("RGBA", (192, 192), (88, 160, 62, 255))
    bg.alpha_composite(d, ((192 - d.width) // 2, (192 - d.height) // 2 + 6))
    bg.save(os.path.join(ROOT, "icon.png"))


if __name__ == "__main__":
    do_dino()
    do_visitors()
    do_enclosures()
    do_tiles()
    do_facilities()
    do_icons()
    do_launcher_icon()
    print("Selesai. Sprite ada di", OUT)
