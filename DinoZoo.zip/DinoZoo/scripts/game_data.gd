class_name GameData
extends RefCounted
# Semua angka keseimbangan game ada di sini. Ubah untuk mengatur kesulitan.

const TILE: int = 64
const GRID_W: int = 32
const GRID_H: int = 20
const GATE_TILE := Vector2i(3, 10)      # petak tempat pengunjung muncul / pulang
const START_MONEY: int = 2500
const DAY_LENGTH: float = 75.0           # detik per hari
const DEFAULT_TICKET: int = 15
const DINO_COST: int = 500
const DINO_APPEAL: float = 10.0
const DINO_FEED: int = 8                 # biaya pakan per dino per hari
const MAX_VISITORS: int = 40
const PATH_COST: int = 5

# Area dalam kandang tempat dino berkeliaran (pecahan ukuran sprite kandang: x, y, lebar, tinggi).
# Kalau sprite kandang diganti, sesuaikan angka ini.
const ENCLOSURE_INTERIOR := Rect2(0.15, 0.24, 0.70, 0.56)

const ENCLOSURE_LEVELS := [
	{"cap": 2, "mult": 1.0, "upgrade": 1200},
	{"cap": 4, "mult": 1.6, "upgrade": 3000},
	{"cap": 6, "mult": 2.4, "upgrade": 0},
]

# size = ukuran petak, cost = harga, appeal = daya tarik, sale = uang per pembelian, chance = peluang beli
const BUILDINGS := {
	"kandang": {"name": "Kandang", "size": Vector2i(4, 4), "cost": 800, "appeal": 0.0, "sale": 0, "chance": 0.0},
	"warung": {"name": "Warung", "size": Vector2i(2, 2), "cost": 300, "appeal": 3.0, "sale": 15, "chance": 0.75},
	"suvenir": {"name": "Suvenir", "size": Vector2i(2, 2), "cost": 500, "appeal": 4.0, "sale": 35, "chance": 0.5},
	"toilet": {"name": "Toilet", "size": Vector2i(2, 2), "cost": 200, "appeal": 8.0, "sale": 0, "chance": 0.0},
	"bangku": {"name": "Bangku", "size": Vector2i(1, 1), "cost": 50, "appeal": 2.0, "sale": 0, "chance": 0.0},
	"pohon": {"name": "Pohon", "size": Vector2i(1, 1), "cost": 30, "appeal": 2.0, "sale": 0, "chance": 0.0},
	"lampu": {"name": "Lampu", "size": Vector2i(1, 1), "cost": 40, "appeal": 2.0, "sale": 0, "chance": 0.0},
	"tong": {"name": "Tong", "size": Vector2i(1, 1), "cost": 20, "appeal": 1.0, "sale": 0, "chance": 0.0},
}

const TOOL_ORDER := ["geser", "jalan", "kandang", "warung", "suvenir", "toilet", "bangku", "pohon", "lampu", "tong", "hapus"]
