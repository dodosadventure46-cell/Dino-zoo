class_name Visitor
extends Node2D
# Pengunjung: muncul di gerbang, jalan lewat jalan setapak ke beberapa tujuan, lalu pulang.

static var frames_cache: Dictionary = {}

var main: Node = null
var sprite: AnimatedSprite2D = null
var cid: int = 0
var pts: Array = []
var stops: Array = []
var cur_tile: Vector2i = Vector2i.ZERO
var current_stop: Building = null
var wait: float = 0.0
var leaving: bool = false
var speed: float = 54.0

func setup(m: Node, tile: Vector2i, stop_list: Array) -> void:
	main = m
	stops = stop_list
	cur_tile = tile
	cid = randi() % 4
	if not frames_cache.has(cid):
		var spec: Dictionary = {}
		for d in ["down", "left", "right", "up"]:
			spec["walk_" + d] = ["res://assets/visitors/v%d_%s" % [cid, d], 8.0]
		frames_cache[cid] = Art.make_frames(spec)
	sprite = AnimatedSprite2D.new()
	sprite.sprite_frames = frames_cache[cid]
	add_child(sprite)
	position = main.foot(tile)
	_play("walk_down")
	sprite.stop()

func _play(anim: String) -> void:
	if sprite.animation != anim:
		var t: Texture2D = sprite.sprite_frames.get_frame_texture(anim, 0)
		sprite.offset = Vector2(0, -t.get_height() * 0.5)
		sprite.play(anim)
	elif not sprite.is_playing():
		sprite.play(anim)

func _process(delta: float) -> void:
	if sprite == null:
		return
	if wait > 0.0:
		wait -= delta
		sprite.stop()
		sprite.frame = 0
		if wait <= 0.0:
			_next()
		return
	if pts.is_empty():
		_arrived()
		return
	var target: Vector2 = pts[0]
	var d: Vector2 = target - position
	var step: float = speed * delta
	if d.length() <= step:
		position = target
		cur_tile = main.world_to_tile(position)
		pts.remove_at(0)
		return
	var dir: Vector2 = d.normalized()
	position += dir * step
	if absf(dir.x) > absf(dir.y):
		_play("walk_right" if dir.x > 0.0 else "walk_left")
	else:
		_play("walk_down" if dir.y > 0.0 else "walk_up")

func _arrived() -> void:
	if leaving:
		main.visitor_left(self)
		queue_free()
	elif current_stop != null:
		if is_instance_valid(current_stop):
			main.visit(self, current_stop)
		current_stop = null
		wait = randf_range(3.0, 6.0)
	else:
		_next()

func _next() -> void:
	while not stops.is_empty():
		var b = stops.pop_front()
		if not is_instance_valid(b):
			continue
		var route: Array = main.find_route(cur_tile, b)
		if route.is_empty():
			continue
		pts = main.route_to_points(route)
		current_stop = b
		return
	leaving = true
	current_stop = null
	pts = main.route_to_points(main.find_route_to_tile(cur_tile, GameData.GATE_TILE))
